package com.escom.bankapi;

public class TransferRequest {

    private Long from;
    private Long to;
    private double amount;

    public Long getFrom() {
        return from;
    }

    public Long getTo() {
        return to;
    }

    public double getAmount() {
        return amount;
    }
}
