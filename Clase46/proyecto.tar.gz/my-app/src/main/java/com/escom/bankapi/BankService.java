package com.escom.bankapi;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class BankService {

    private final Map<Long, Account> accounts =
            new ConcurrentHashMap<>();

    public BankService() {

        accounts.put(
                1L,
                new Account(
                        1L,
                        "Juan",
                        12000));

        accounts.put(
                2L,
                new Account(
                        2L,
                        "Maria",
                        9000));
    }

    public Account findAccount(Long id) {
        return accounts.get(id);
    }

    public synchronized boolean transfer(
            Long from,
            Long to,
            double amount) {

        Account source = accounts.get(from);
        Account target = accounts.get(to);

        if (source == null || target == null)
            return false;

        if (source.getBalance() < amount)
            return false;

        source.setBalance(
                source.getBalance() - amount);

        target.setBalance(
                target.getBalance() + amount);

        return true;
    }
}
