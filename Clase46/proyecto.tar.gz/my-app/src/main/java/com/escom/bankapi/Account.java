package com.escom.bankapi;

public class Account {

    private Long id;
    private String owner;
    private double balance;

    public Account(Long id,
                   String owner,
                   double balance) {

        this.id = id;
        this.owner = owner;
        this.balance = balance;
    }

    public Long getId() {
        return id;
    }

    public String getOwner() {
        return owner;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
