package com.escom.bankapi;

import com.google.gson.Gson;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicLong;

public class Main {

    private static final Gson gson =
            new Gson();

    private static final BankService bankService =
            new BankService();

    private static final AtomicLong requests =
            new AtomicLong();

    public static void main(String[] args)
            throws Exception {

        HttpServer server =
                HttpServer.create(
                        new InetSocketAddress(8080),
                        0);

        server.createContext(
                "/api/info",
                Main::handleInfo);

        server.createContext(
                "/api/accounts",
                Main::handleAccount);

        server.createContext(
                "/api/transfer",
                Main::handleTransfer);

        server.setExecutor(
                Executors.newFixedThreadPool(10));

        server.start();

        System.out.println(
                "Servidor iniciado en puerto 8080");
    }

    private static void handleInfo(
            HttpExchange exchange) {

        try {

            requests.incrementAndGet();

            String host =
                    System.getenv()
                            .getOrDefault(
                                    "HOSTNAME",
                                    "localhost");

            Map<String,Object> response =
                    Map.of(
                            "host", host,
                            "requests",
                            requests.get()
                    );

            sendJson(exchange, response);

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    private static void handleAccount(
            HttpExchange exchange) {

        try {

            requests.incrementAndGet();

            String path =
                    exchange.getRequestURI()
                            .getPath();

            String[] parts =
                    path.split("/");

            Long id =
                    Long.parseLong(
                            parts[3]);

            Account account =
                    bankService.findAccount(id);

            if(account == null) {

                exchange.sendResponseHeaders(
                        404,
                        -1);

                return;
            }

            sendJson(exchange, account);

        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    private static void handleTransfer(
            HttpExchange exchange) {

        try {

            requests.incrementAndGet();

            if(!exchange.getRequestMethod()
                    .equalsIgnoreCase(
                            "POST")) {

                exchange.sendResponseHeaders(
                        405,
                        -1);

                return;
            }

            InputStream is =
                    exchange.getRequestBody();

            String json =
                    new String(
                            is.readAllBytes());

            TransferRequest request =
                    gson.fromJson(
                            json,
                            TransferRequest.class);

            boolean ok =
                    bankService.transfer(
                            request.getFrom(),
                            request.getTo(),
                            request.getAmount());

            sendJson(
                    exchange,
                    Map.of(
                            "status",
                            ok ? "OK" : "ERROR"));
        }
        catch(Exception e) {
            e.printStackTrace();
        }
    }

    private static void sendJson(
            HttpExchange exchange,
            Object object)
            throws Exception {

        String json =
                gson.toJson(object);

        exchange.getResponseHeaders()
                .set(
                        "Content-Type",
                        "application/json");

        exchange.sendResponseHeaders(
                200,
                json.getBytes().length);

        OutputStream os =
                exchange.getResponseBody();

        os.write(json.getBytes());

        os.close();
    }
}
